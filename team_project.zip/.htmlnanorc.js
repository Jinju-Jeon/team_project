module.exports = {
    "minifySvg": false
    }