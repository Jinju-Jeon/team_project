const { expr } = require("jquery")

let popSearch = [
    'test',
    'ttest'
]

let recomSearch = [
    'test',
    'ttest']

let recentSearch = [
    'test',
    'ttest']


export default {popSearch, recomSearch, recentSearch}